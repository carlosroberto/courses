from django.apps import AppConfig


class ClientesConfig(AppConfig):
    name = 'clientes'
